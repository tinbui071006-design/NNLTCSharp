namespace BaiThucHanhLINQ;

partial class Program {
    //Bài 3.1: thống kê mảng số bằng Count, Sum, Min, Max, Distinct, GroupBy
    static void Bai31() {
        TieuDe("BÀI 3.1. THỐNG KÊ MẢNG SỐ");
        int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };
        InDay("Mảng ban đầu: ", mangSo);

        //a. Tổng số phần tử, số phần tử chẵn, số phần tử lẻ
        Cau("a. Số phần tử");
        int tongPhanTu = mangSo.Count();
        int soChan = mangSo.Count(n => n % 2 == 0);
        int soLe = (from n in mangSo where n % 2 != 0 select n).Count();
        Console.WriteLine($"Tổng số phần tử : {tongPhanTu}");
        Console.WriteLine($"Số phần tử chẵn : {soChan}");
        Console.WriteLine($"Số phần tử lẻ   : {soLe}");

        //b. Tổng, giá trị lớn nhất, nhỏ nhất (thêm trung bình để dùng Average)
        Cau("b. Tổng, lớn nhất, nhỏ nhất");
        Console.WriteLine($"Tổng các giá trị : {mangSo.Sum()}");
        Console.WriteLine($"Giá trị lớn nhất : {mangSo.Max()}");
        Console.WriteLine($"Giá trị nhỏ nhất : {mangSo.Min()}");
        Console.WriteLine($"Trung bình cộng  : {mangSo.Average():0.##}");

        //c. Số giá trị khác nhau
        Cau("c. Số giá trị khác nhau");
        var khacNhau = mangSo.Distinct();
        Console.WriteLine($"Có {khacNhau.Count()} giá trị khác nhau: {string.Join(", ", khacNhau)}");

        //d. Phân nhóm theo số dư khi chia cho 5
        Cau("d. Phân nhóm theo số dư khi chia cho 5");
        var nhomQuery = from n in mangSo
                        group n by n % 5 into g
                        orderby g.Key
                        select g;
        foreach (var g in nhomQuery) {
            Console.WriteLine($"Số dư {g.Key}: {string.Join(", ", g)}");
        }
    }

    //Bài 3.2: thống kê mảng chuỗi
    static void Bai32() {
        TieuDe("BÀI 3.2. THỐNG KÊ MẢNG CHUỖI");
        string[] monAn = { "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì", "Nước Cà phê",
                           "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào", "Bún riêu",
                           "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang" };

        //a. Phần tử ngắn nhất và dài nhất (có thể có nhiều phần tử cùng độ dài)
        Cau("a. Phần tử có chiều dài ngắn nhất và dài nhất");
        int doDaiMin = monAn.Min(s => s.Length);
        int doDaiMax = monAn.Max(s => s.Length);
        var nganNhat = monAn.Where(s => s.Length == doDaiMin);
        var daiNhat = from s in monAn
                      where s.Length == doDaiMax
                      select s;
        Console.WriteLine($"Ngắn nhất ({doDaiMin} ký tự): {string.Join(", ", nganNhat)}");
        Console.WriteLine($"Dài nhất  ({doDaiMax} ký tự): {string.Join(", ", daiNhat)}");

        //b. Phân nhóm theo từ đầu tiên của tên món
        Cau("b. Phân nhóm theo từ đầu tiên");
        var nhom = monAn.GroupBy(s => s.Split(' ')[0]);
        foreach (var g in nhom) {
            Console.WriteLine($"{g.Key} ({g.Count()} món): {string.Join(", ", g)}");
        }

        //c. Đếm số món có từ đầu tiên là "Bánh"
        Cau("c. Số món có từ đầu tiên là \"Bánh\"");
        int soMonBanh = monAn.Count(s => s.Split(' ')[0] == "Bánh");
        Console.WriteLine($"Có {soMonBanh} món");
    }
}
