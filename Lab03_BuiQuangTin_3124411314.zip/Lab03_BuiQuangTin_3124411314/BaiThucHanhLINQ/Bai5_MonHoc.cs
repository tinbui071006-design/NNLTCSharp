namespace BaiThucHanhLINQ;

partial class Program {
    //Bài 4.1: in nguồn dữ liệu List<MonHoc> lấy từ DuLieu.DS_Mon()
    static void Bai41() {
        TieuDe("BÀI 4.1. NGUỒN DỮ LIỆU List<MonHoc>");
        List<MonHoc> dsMon = DuLieu.DS_Mon();
        Console.WriteLine($"Đã tạo {dsMon.Count} môn học:");
        foreach (var m in dsMon) {
            Console.WriteLine(m);
        }
    }

    //Bài 5.1: truy vấn cơ bản trên List<MonHoc>
    static void Bai51() {
        TieuDe("BÀI 5.1. TRUY VẤN CƠ BẢN TRÊN List<MonHoc>");
        List<MonHoc> dsMon = DuLieu.DS_Mon();

        //a. Tên các môn bắt đầu bằng "Lập trình"
        Cau("a. Tên các môn bắt đầu bằng \"Lập trình\"");
        var aQuery = from m in dsMon
                     where m.TenMon.StartsWith("Lập trình")
                     select m.TenMon;
        var aMethod = dsMon.Where(m => m.TenMon.StartsWith("Lập trình")).Select(m => m.TenMon);
        Console.WriteLine("Query syntax :");
        foreach (var ten in aQuery) Console.WriteLine($"  {ten}");
        Console.WriteLine("Method syntax:");
        foreach (var ten in aMethod) Console.WriteLine($"  {ten}");

        //b. Môn hệ CD, số tiết giảm dần rồi mã môn tăng dần
        Cau("b. Các môn hệ CD, số tiết giảm dần, mã môn tăng dần");
        var bQuery = from m in dsMon
                     where m.He == "CD"
                     orderby m.SoTiet descending, m.MaMon
                     select m;
        var bMethod = dsMon.Where(m => m.He == "CD")
                           .OrderByDescending(m => m.SoTiet)
                           .ThenBy(m => m.MaMon);
        Console.WriteLine("Query syntax :");
        foreach (var m in bQuery) Console.WriteLine($"  {m}");
        Console.WriteLine($"Method syntax cho cùng kết quả: {bQuery.SequenceEqual(bMethod)}");

        //c. Môn có tên chứa "web" (không phân biệt hoa thường), chỉ lấy Tên môn và Hệ
        Cau("c. Các môn có tên chứa \"web\" (Tên môn, Hệ)");
        var cQuery = from m in dsMon
                     where m.TenMon.Contains("web", StringComparison.OrdinalIgnoreCase)
                     select new { m.TenMon, m.He };
        var cMethod = dsMon.Where(m => m.TenMon.Contains("web", StringComparison.OrdinalIgnoreCase))
                           .Select(m => new { m.TenMon, m.He });
        Console.WriteLine("Query syntax :");
        foreach (var x in cQuery) Console.WriteLine($"  {x.TenMon,-44} | {x.He}");
        Console.WriteLine("Method syntax:");
        foreach (var x in cMethod) Console.WriteLine($"  {x.TenMon,-44} | {x.He}");

        //d. Môn hệ KTV, sắp tăng theo mã môn
        Cau("d. Các môn hệ KTV, mã môn tăng dần");
        var dQuery = from m in dsMon
                     where m.He == "KTV"
                     orderby m.MaMon
                     select m;
        var dMethod = dsMon.Where(m => m.He == "KTV").OrderBy(m => m.MaMon);
        Console.WriteLine("Query syntax :");
        foreach (var m in dQuery) Console.WriteLine($"  {m}");
        Console.WriteLine($"Method syntax cho cùng kết quả: {dQuery.SequenceEqual(dMethod)}");
    }

    //Bài 5.2: thống kê trên List<MonHoc>
    static void Bai52() {
        TieuDe("BÀI 5.2. THỐNG KÊ TRÊN List<MonHoc>");
        List<MonHoc> dsMon = DuLieu.DS_Mon();

        //a. Tổng số môn
        Cau("a. Tổng số môn hiện có");
        Console.WriteLine($"Tổng số môn: {dsMon.Count()}");

        //b. Số môn có tên bắt đầu bằng "Lập trình"
        Cau("b. Số môn có tên bắt đầu bằng \"Lập trình\"");
        Console.WriteLine($"Số môn: {dsMon.Count(m => m.TenMon.StartsWith("Lập trình"))}");

        //c. Tổng số tiết của hệ KTV
        Cau("c. Tổng số tiết của hệ Kỹ thuật viên (KTV)");
        int tongTietKTV = dsMon.Where(m => m.He == "KTV").Sum(m => (int)m.SoTiet);
        Console.WriteLine($"Tổng số tiết: {tongTietKTV}");

        //d. Tổng số môn của mỗi hệ
        Cau("d. Tổng số môn của mỗi hệ");
        var dTheoHe = from m in dsMon
                      group m by m.He into g
                      select new { He = g.Key, TongSoMon = g.Count() };
        Console.WriteLine($"{"Hệ",-8} | Tổng số môn");
        foreach (var x in dTheoHe) Console.WriteLine($"{TenHeHienThi(x.He),-8} | {x.TongSoMon}");

        //e. Nhóm theo số tiết, giảm dần theo số tiết
        Cau("e. Nhóm theo số tiết (giảm dần)");
        var eTheoTiet = dsMon.GroupBy(m => m.SoTiet)
                             .OrderByDescending(g => g.Key)
                             .Select(g => new { SoTiet = g.Key, TongSoMon = g.Count() });
        Console.WriteLine("Số tiết | Tổng số môn");
        foreach (var x in eTheoTiet) Console.WriteLine($"{x.SoTiet,7} | {x.TongSoMon}");

        //f. Môn có số tiết cao nhất (lấy tất cả nếu có nhiều môn bằng nhau)
        Cau("f. Môn học có số tiết cao nhất");
        byte tietMax = dsMon.Max(m => m.SoTiet);
        var fMax = dsMon.Where(m => m.SoTiet == tietMax);
        foreach (var m in fMax) Console.WriteLine(m);

        //g. Thống kê theo hệ: số môn, tổng tiết, tiết cao nhất, thấp nhất
        Cau("g. Thống kê theo Hệ");
        var gThongKe = from m in dsMon
                       group m by m.He into g
                       select new {
                           He = g.Key,
                           SoMon = g.Count(),
                           TongTiet = g.Sum(x => (int)x.SoTiet),
                           TietMax = g.Max(x => x.SoTiet),
                           TietMin = g.Min(x => x.SoTiet)
                       };
        Console.WriteLine($"{"Hệ",-8} | Số môn | Tổng tiết | Cao nhất | Thấp nhất");
        foreach (var x in gThongKe) {
            Console.WriteLine($"{TenHeHienThi(x.He),-8} | {x.SoMon,6} | {x.TongTiet,9} | {x.TietMax,8} | {x.TietMin,9}");
        }

        //h. Liệt kê các môn phân nhóm theo hệ
        Cau("h. Các môn học phân nhóm theo Hệ");
        var hNhom = dsMon.GroupBy(m => m.He);
        foreach (var g in hNhom) {
            Console.WriteLine($"Hệ {TenHeHienThi(g.Key)} ({g.Count()} môn):");
            foreach (var m in g) Console.WriteLine($"  {m}");
        }

        //i. Phân nhóm theo số tiết, tăng dần theo số tiết
        Cau("i. Các môn học phân nhóm theo Số tiết (tăng dần)");
        var iNhom = from m in dsMon
                    group m by m.SoTiet into g
                    orderby g.Key
                    select g;
        foreach (var g in iNhom) {
            Console.WriteLine($"Số tiết {g.Key} ({g.Count()} môn):");
            foreach (var m in g) Console.WriteLine($"  {m}");
        }

        //j. Hệ KTV, phân nhóm theo học phần HP2..HP5, sắp theo mã môn
        Cau("j. Hệ KTV phân nhóm theo học phần");
        var jNhom = from m in dsMon
                    where m.He == "KTV"
                    orderby m.MaMon
                    group m by m.MaMon.Substring(0, 3) into g
                    orderby g.Key
                    select g;
        foreach (var g in jNhom) {
            Console.WriteLine($"Học phần {g.Key}:");
            foreach (var m in g) Console.WriteLine($"  {m}");
        }

        //k. Phân nhóm theo hệ, chỉ lấy môn có số tiết > 40, mỗi nhóm sắp theo mã môn
        Cau("k. Phân nhóm theo Hệ, chỉ lấy môn có Số tiết > 40");
        var kNhom = dsMon.Where(m => m.SoTiet > 40)
                         .GroupBy(m => m.He)
                         .Select(g => new { He = g.Key, DsMon = g.OrderBy(m => m.MaMon) });
        foreach (var g in kNhom) {
            Console.WriteLine($"Hệ {TenHeHienThi(g.He)}:");
            foreach (var m in g.DsMon) Console.WriteLine($"  {m}");
        }
    }
}
