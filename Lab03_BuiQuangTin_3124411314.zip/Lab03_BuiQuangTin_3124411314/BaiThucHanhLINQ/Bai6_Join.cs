namespace BaiThucHanhLINQ;

partial class Program {
    //Bài 6.1: in nguồn dữ liệu List<He> lấy từ DuLieu.DS_He()
    static void Bai61() {
        TieuDe("BÀI 6.1. NGUỒN DỮ LIỆU List<He>");
        List<He> dsHe = DuLieu.DS_He();
        Console.WriteLine($"{"Mã hệ",-6} | Tên hệ");
        foreach (var h in dsHe) Console.WriteLine($"{h.MaHe,-6} | {h.TenHe}");
    }

    //Bài 6.2: join hai nguồn dữ liệu List<MonHoc> và List<He>
    static void Bai62() {
        TieuDe("BÀI 6.2. JOIN VÀ CÁC TOÁN TỬ TẬP HỢP");
        List<MonHoc> dsMon = DuLieu.DS_Mon();
        List<He> dsHe = DuLieu.DS_He();

        //a. Inner join: Tên hệ, Mã môn, Tên môn
        Cau("a. Inner join: Tên hệ, Mã môn, Tên môn");
        var aQuery = from m in dsMon
                     join h in dsHe on m.He equals h.MaHe
                     select new { h.TenHe, m.MaMon, m.TenMon };
        var aMethod = dsMon.Join(dsHe, m => m.He, h => h.MaHe,
                                 (m, h) => new { h.TenHe, m.MaMon, m.TenMon });
        foreach (var x in aQuery) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");
        Console.WriteLine($"Số dòng: {aQuery.Count()} (Method syntax: {aMethod.Count()})");

        //b. Left outer join: lấy cả hệ chưa có môn
        Cau("b. Left join: liệt kê cả hệ chưa có môn học");
        var heTraiMon = from h in dsHe
                        join m in dsMon on h.MaHe equals m.He into nhomMon
                        from m in nhomMon.DefaultIfEmpty()
                        select new {
                            TenHe = h.TenHe,
                            MaMon = m == null ? "" : m.MaMon,
                            TenMon = m == null ? "(chưa có môn học)" : m.TenMon
                        };
        foreach (var x in heTraiMon) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

        //Môn học không khớp với hệ nào (chưa khai báo hệ), dùng cho câu c và d
        var monChuaCoHe = from m in dsMon
                          join h in dsHe on m.He equals h.MaHe into nhomHe
                          from h in nhomHe.DefaultIfEmpty()
                          where h == null
                          select new {
                              TenHe = "(chưa khai báo hệ)",
                              MaMon = m.MaMon,
                              TenMon = m.TenMon
                          };

        //c. Full outer join = left join (hệ -> môn) + các môn chưa có hệ
        Cau("c. Liệt kê cả hệ chưa có môn và môn chưa khai báo hệ");
        var cFull = heTraiMon.Concat(monChuaCoHe);
        foreach (var x in cFull) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

        //d. Chỉ lấy phần không khớp của hai phía
        Cau("d. Chỉ hệ chưa có môn và môn chưa khai báo hệ");
        var heChuaCoMon = heTraiMon.Where(x => x.MaMon == "");
        var dKhongKhop = heChuaCoMon.Concat(monChuaCoHe);
        foreach (var x in dKhongKhop) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

        //e. 5 môn đầu tiên có số tiết giảm dần
        Cau("e. 5 môn đầu tiên có số tiết giảm dần");
        var eTop5 = (from m in dsMon
                     join h in dsHe on m.He equals h.MaHe into nhomHe
                     from h in nhomHe.DefaultIfEmpty()
                     orderby m.SoTiet descending, m.MaMon
                     select new {
                         TenHe = h == null ? "(chưa khai báo hệ)" : h.TenHe,
                         m.MaMon,
                         m.TenMon,
                         m.SoTiet
                     }).Take(5);
        foreach (var x in eTop5) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon,-44} | {x.SoTiet,3}");

        //f. Tổng số môn của mỗi hệ (GroupJoin giữ cả hệ có 0 môn)
        Cau("f. Tổng số môn học của mỗi hệ");
        var fTongMon = dsHe.GroupJoin(dsMon, h => h.MaHe, m => m.He,
                                      (h, nhomMon) => new { h.MaHe, h.TenHe, TongSoMon = nhomMon.Count() });
        Console.WriteLine($"{"Mã hệ",-6} | {"Tên hệ",-18} | Tổng số môn");
        foreach (var x in fTongMon) Console.WriteLine($"{x.MaHe,-6} | {x.TenHe,-18} | {x.TongSoMon}");

        //g. Số loại số tiết khác nhau
        Cau("g. Số loại Số tiết khác nhau");
        var gLoaiTiet = dsMon.Select(m => m.SoTiet).Distinct().OrderBy(t => t);
        Console.WriteLine($"Có {gLoaiTiet.Count()} loại số tiết: {string.Join(", ", gLoaiTiet)}");

        //h. Môn đầu tiên có tên bắt đầu bằng "Lập trình"
        Cau("h. Môn học đầu tiên có tên bắt đầu bằng \"Lập trình\"");
        MonHoc? hDauTien = dsMon.FirstOrDefault(m => m.TenMon.StartsWith("Lập trình"));
        Console.WriteLine(hDauTien == null ? "Không tìm thấy" : hDauTien.ToString());

        //i. Liệt kê môn theo từng hệ, đánh số thứ tự trong mỗi nhóm
        Cau("i. Các môn theo từng hệ, có số thứ tự trong nhóm");
        var iTheoHe = from m in dsMon
                      group m by m.He into g
                      join h in dsHe on g.Key equals h.MaHe into nhomHe
                      from h in nhomHe.DefaultIfEmpty()
                      select new {
                          TenHe = h == null ? "(chưa khai báo hệ)" : h.TenHe,
                          DsMon = g.OrderBy(m => m.MaMon)
                                   .Select((m, i) => new { STT = i + 1, m.MaMon, m.TenMon })
                      };
        foreach (var g in iTheoHe) {
            Console.WriteLine($"{g.TenHe}:");
            foreach (var x in g.DsMon) Console.WriteLine($"  {x.STT,2}. {x.MaMon,-6} | {x.TenMon}");
        }
    }
}
