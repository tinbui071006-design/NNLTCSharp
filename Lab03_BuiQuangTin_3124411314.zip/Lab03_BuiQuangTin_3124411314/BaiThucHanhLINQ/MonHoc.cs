namespace BaiThucHanhLINQ;

//Bài 4.1: lớp MonHoc mô tả một môn học
public class MonHoc {
    public string MaMon { get; set; } = "";
    public string TenMon { get; set; } = "";
    public string He { get; set; } = "";
    public byte SoTiet { get; set; }

    public override string ToString() =>
        $"{MaMon,-6} | {TenMon,-44} | {(He == "" ? "(trống)" : He),-7} | {SoTiet,3}";
}

//Bài 6.1: lớp He mô tả một hệ đào tạo
public class He {
    public string MaHe { get; set; } = "";
    public string TenHe { get; set; } = "";
}
