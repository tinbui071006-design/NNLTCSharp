﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaiThucHanhLINQ;

partial class Program {
    static void Main() {
        Console.OutputEncoding = Encoding.UTF8;

        //Gọi lần lượt các hàm bài tập
        Bai21();
        Bai22();
        Bai31();
        Bai32();
        Bai41();
        Bai51();
        Bai52();
        Bai61();
        Bai62();
    }

    //In tiêu đề của một bài
    static void TieuDe(string ten) {
        Console.WriteLine();
        Console.WriteLine(new string('=', 70));
        Console.WriteLine(ten);
        Console.WriteLine(new string('=', 70));
    }

    //In nhãn của một câu
    static void Cau(string nhan) {
        Console.WriteLine();
        Console.WriteLine($"--- {nhan}");
    }

    //In một dãy giá trị trên cùng một dòng, cách nhau bởi dấu phẩy
    static void InDay<T>(string nhan, IEnumerable<T> day) {
        Console.WriteLine($"{nhan}{string.Join(", ", day)}");
    }

    //Hiển thị hệ rỗng cho dễ đọc
    static string TenHeHienThi(string he) => he == "" ? "(trống)" : he;
}
