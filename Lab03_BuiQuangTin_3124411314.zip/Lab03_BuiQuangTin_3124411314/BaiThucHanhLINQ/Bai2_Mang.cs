namespace BaiThucHanhLINQ;

partial class Program {
    //Bài 2.1: truy vấn LINQ trên mảng số nguyên
    static void Bai21() {
        TieuDe("BÀI 2.1. TRUY VẤN MẢNG SỐ NGUYÊN");
        int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };
        InDay("Mảng ban đầu: ", mangSo);

        //a. Phần tử chia hết cho 4 và 3
        Cau("a. Các phần tử chia hết cho 4 và 3");
        var aQuery = from n in mangSo
                     where n % 4 == 0 && n % 3 == 0
                     select n;
        var aMethod = mangSo.Where(n => n % 4 == 0 && n % 3 == 0);
        InDay("Query syntax : ", aQuery);
        InDay("Method syntax: ", aMethod);

        //b. Phần tử nhỏ hơn hoặc bằng 3
        Cau("b. Các phần tử nhỏ hơn hoặc bằng 3");
        var bQuery = from n in mangSo
                     where n <= 3
                     select n;
        var bMethod = mangSo.Where(n => n <= 3);
        InDay("Query syntax : ", bQuery);
        InDay("Method syntax: ", bMethod);

        //c. Số chẵn chia đôi, số lẻ giữ nguyên
        Cau("c. Dãy mới: số chẵn chia đôi, số lẻ giữ nguyên");
        var cQuery = from n in mangSo
                     select n % 2 == 0 ? n / 2 : n;
        var cMethod = mangSo.Select(n => n % 2 == 0 ? n / 2 : n);
        InDay("Query syntax : ", cQuery);
        InDay("Method syntax: ", cMethod);
    }

    //Bài 2.2: truy vấn LINQ trên mảng chuỗi
    static void Bai22() {
        TieuDe("BÀI 2.2. TRUY VẤN MẢNG CHUỖI");
        string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều",
                               "là", "chị", "em", "là", "Thúy", "Vân" };
        InDay("Mảng ban đầu: ", mangChuoi);

        //a. Phần tử có 4 ký tự, sắp tăng theo ký tự đầu tiên
        Cau("a. Các phần tử có 4 ký tự, sắp tăng dần theo ký tự đầu");
        var aQuery = from s in mangChuoi
                     where s.Length == 4
                     orderby s[0]
                     select s;
        var aMethod = mangChuoi.Where(s => s.Length == 4).OrderBy(s => s[0]);
        InDay("Query syntax : ", aQuery);
        InDay("Method syntax: ", aMethod);

        //b. Biến đổi thành dạng <chữ thường> - <CHỮ HOA>
        Cau("b. Dạng <chữ thường> - <CHỮ HOA>");
        var bQuery = from s in mangChuoi
                     select $"{s.ToLower()} - {s.ToUpper()}";
        var bMethod = mangChuoi.Select(s => $"{s.ToLower()} - {s.ToUpper()}");
        InDay("Query syntax : ", bQuery);
        InDay("Method syntax: ", bMethod);

        //c. Phần tử có chứa ký tự "u"
        Cau("c. Các phần tử có chứa ký tự \"u\"");
        var cQuery = from s in mangChuoi
                     where s.Contains("u")
                     select s;
        var cMethod = mangChuoi.Where(s => s.Contains("u"));
        InDay("Query syntax : ", cQuery);
        InDay("Method syntax: ", cMethod);

        //d. Chọn các phần tử bắt đầu bằng chữ in hoa
        Cau("d. Các phần tử bắt đầu bằng chữ in hoa");
        var dQuery = from s in mangChuoi
                     where char.IsUpper(s[0])
                     select s;
        var dMethod = mangChuoi.Where(s => char.IsUpper(s[0]));
        Console.WriteLine($"Query syntax : {string.Join(" ", dQuery)}");
        Console.WriteLine($"Method syntax: {string.Join(" ", dMethod)}");
    }
}
