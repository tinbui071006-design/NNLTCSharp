<Query Kind="Program" />
//Lab 03 - LINQ cơ bản, bản chạy trên LINQPad
//Mở file bằng LINQPad (Language: C# Program) rồi nhấn F5, kết quả hiện ở khung Results
//Có thể thêm .Dump() sau một truy vấn để LINQPad hiển thị dạng bảng, ví dụ: DuLieu.DS_Mon().Dump();

void Main() {
    Console.OutputEncoding = Encoding.UTF8;

    //Gọi lần lượt các hàm bài tập
    Bai21();
    Bai22();
    Bai31();
    Bai32();
    Bai41();
    Bai51();
    Bai52();
    Bai61();
    Bai62();
}

//In tiêu đề của một bài
static void TieuDe(string ten) {
    Console.WriteLine();
    Console.WriteLine(new string('=', 70));
    Console.WriteLine(ten);
    Console.WriteLine(new string('=', 70));
}

//In nhãn của một câu
static void Cau(string nhan) {
    Console.WriteLine();
    Console.WriteLine($"--- {nhan}");
}

//In một dãy giá trị trên cùng một dòng, cách nhau bởi dấu phẩy
static void InDay<T>(string nhan, IEnumerable<T> day) {
    Console.WriteLine($"{nhan}{string.Join(", ", day)}");
}

//Hiển thị hệ rỗng cho dễ đọc
static string TenHeHienThi(string he) => he == "" ? "(trống)" : he;

//Bài 2.1: truy vấn LINQ trên mảng số nguyên
static void Bai21() {
    TieuDe("BÀI 2.1. TRUY VẤN MẢNG SỐ NGUYÊN");
    int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };
    InDay("Mảng ban đầu: ", mangSo);

    //a. Phần tử chia hết cho 4 và 3
    Cau("a. Các phần tử chia hết cho 4 và 3");
    var aQuery = from n in mangSo
                 where n % 4 == 0 && n % 3 == 0
                 select n;
    var aMethod = mangSo.Where(n => n % 4 == 0 && n % 3 == 0);
    InDay("Query syntax : ", aQuery);
    InDay("Method syntax: ", aMethod);

    //b. Phần tử nhỏ hơn hoặc bằng 3
    Cau("b. Các phần tử nhỏ hơn hoặc bằng 3");
    var bQuery = from n in mangSo
                 where n <= 3
                 select n;
    var bMethod = mangSo.Where(n => n <= 3);
    InDay("Query syntax : ", bQuery);
    InDay("Method syntax: ", bMethod);

    //c. Số chẵn chia đôi, số lẻ giữ nguyên
    Cau("c. Dãy mới: số chẵn chia đôi, số lẻ giữ nguyên");
    var cQuery = from n in mangSo
                 select n % 2 == 0 ? n / 2 : n;
    var cMethod = mangSo.Select(n => n % 2 == 0 ? n / 2 : n);
    InDay("Query syntax : ", cQuery);
    InDay("Method syntax: ", cMethod);
}

//Bài 2.2: truy vấn LINQ trên mảng chuỗi
static void Bai22() {
    TieuDe("BÀI 2.2. TRUY VẤN MẢNG CHUỖI");
    string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều",
                           "là", "chị", "em", "là", "Thúy", "Vân" };
    InDay("Mảng ban đầu: ", mangChuoi);

    //a. Phần tử có 4 ký tự, sắp tăng theo ký tự đầu tiên
    Cau("a. Các phần tử có 4 ký tự, sắp tăng dần theo ký tự đầu");
    var aQuery = from s in mangChuoi
                 where s.Length == 4
                 orderby s[0]
                 select s;
    var aMethod = mangChuoi.Where(s => s.Length == 4).OrderBy(s => s[0]);
    InDay("Query syntax : ", aQuery);
    InDay("Method syntax: ", aMethod);

    //b. Biến đổi thành dạng <chữ thường> - <CHỮ HOA>
    Cau("b. Dạng <chữ thường> - <CHỮ HOA>");
    var bQuery = from s in mangChuoi
                 select $"{s.ToLower()} - {s.ToUpper()}";
    var bMethod = mangChuoi.Select(s => $"{s.ToLower()} - {s.ToUpper()}");
    InDay("Query syntax : ", bQuery);
    InDay("Method syntax: ", bMethod);

    //c. Phần tử có chứa ký tự "u"
    Cau("c. Các phần tử có chứa ký tự \"u\"");
    var cQuery = from s in mangChuoi
                 where s.Contains("u")
                 select s;
    var cMethod = mangChuoi.Where(s => s.Contains("u"));
    InDay("Query syntax : ", cQuery);
    InDay("Method syntax: ", cMethod);

    //d. Chọn các phần tử bắt đầu bằng chữ in hoa
    Cau("d. Các phần tử bắt đầu bằng chữ in hoa");
    var dQuery = from s in mangChuoi
                 where char.IsUpper(s[0])
                 select s;
    var dMethod = mangChuoi.Where(s => char.IsUpper(s[0]));
    Console.WriteLine($"Query syntax : {string.Join(" ", dQuery)}");
    Console.WriteLine($"Method syntax: {string.Join(" ", dMethod)}");
}

//Bài 3.1: thống kê mảng số bằng Count, Sum, Min, Max, Distinct, GroupBy
static void Bai31() {
    TieuDe("BÀI 3.1. THỐNG KÊ MẢNG SỐ");
    int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };
    InDay("Mảng ban đầu: ", mangSo);

    //a. Tổng số phần tử, số phần tử chẵn, số phần tử lẻ
    Cau("a. Số phần tử");
    int tongPhanTu = mangSo.Count();
    int soChan = mangSo.Count(n => n % 2 == 0);
    int soLe = (from n in mangSo where n % 2 != 0 select n).Count();
    Console.WriteLine($"Tổng số phần tử : {tongPhanTu}");
    Console.WriteLine($"Số phần tử chẵn : {soChan}");
    Console.WriteLine($"Số phần tử lẻ   : {soLe}");

    //b. Tổng, giá trị lớn nhất, nhỏ nhất (thêm trung bình để dùng Average)
    Cau("b. Tổng, lớn nhất, nhỏ nhất");
    Console.WriteLine($"Tổng các giá trị : {mangSo.Sum()}");
    Console.WriteLine($"Giá trị lớn nhất : {mangSo.Max()}");
    Console.WriteLine($"Giá trị nhỏ nhất : {mangSo.Min()}");
    Console.WriteLine($"Trung bình cộng  : {mangSo.Average():0.##}");

    //c. Số giá trị khác nhau
    Cau("c. Số giá trị khác nhau");
    var khacNhau = mangSo.Distinct();
    Console.WriteLine($"Có {khacNhau.Count()} giá trị khác nhau: {string.Join(", ", khacNhau)}");

    //d. Phân nhóm theo số dư khi chia cho 5
    Cau("d. Phân nhóm theo số dư khi chia cho 5");
    var nhomQuery = from n in mangSo
                    group n by n % 5 into g
                    orderby g.Key
                    select g;
    foreach (var g in nhomQuery) {
        Console.WriteLine($"Số dư {g.Key}: {string.Join(", ", g)}");
    }
}

//Bài 3.2: thống kê mảng chuỗi
static void Bai32() {
    TieuDe("BÀI 3.2. THỐNG KÊ MẢNG CHUỖI");
    string[] monAn = { "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì", "Nước Cà phê",
                       "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào", "Bún riêu",
                       "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang" };

    //a. Phần tử ngắn nhất và dài nhất (có thể có nhiều phần tử cùng độ dài)
    Cau("a. Phần tử có chiều dài ngắn nhất và dài nhất");
    int doDaiMin = monAn.Min(s => s.Length);
    int doDaiMax = monAn.Max(s => s.Length);
    var nganNhat = monAn.Where(s => s.Length == doDaiMin);
    var daiNhat = from s in monAn
                  where s.Length == doDaiMax
                  select s;
    Console.WriteLine($"Ngắn nhất ({doDaiMin} ký tự): {string.Join(", ", nganNhat)}");
    Console.WriteLine($"Dài nhất  ({doDaiMax} ký tự): {string.Join(", ", daiNhat)}");

    //b. Phân nhóm theo từ đầu tiên của tên món
    Cau("b. Phân nhóm theo từ đầu tiên");
    var nhom = monAn.GroupBy(s => s.Split(' ')[0]);
    foreach (var g in nhom) {
        Console.WriteLine($"{g.Key} ({g.Count()} món): {string.Join(", ", g)}");
    }

    //c. Đếm số món có từ đầu tiên là "Bánh"
    Cau("c. Số món có từ đầu tiên là \"Bánh\"");
    int soMonBanh = monAn.Count(s => s.Split(' ')[0] == "Bánh");
    Console.WriteLine($"Có {soMonBanh} món");
}

//Bài 4.1: in nguồn dữ liệu List<MonHoc> lấy từ DuLieu.DS_Mon()
static void Bai41() {
    TieuDe("BÀI 4.1. NGUỒN DỮ LIỆU List<MonHoc>");
    List<MonHoc> dsMon = DuLieu.DS_Mon();
    Console.WriteLine($"Đã tạo {dsMon.Count} môn học:");
    foreach (var m in dsMon) {
        Console.WriteLine(m);
    }
}

//Bài 5.1: truy vấn cơ bản trên List<MonHoc>
static void Bai51() {
    TieuDe("BÀI 5.1. TRUY VẤN CƠ BẢN TRÊN List<MonHoc>");
    List<MonHoc> dsMon = DuLieu.DS_Mon();

    //a. Tên các môn bắt đầu bằng "Lập trình"
    Cau("a. Tên các môn bắt đầu bằng \"Lập trình\"");
    var aQuery = from m in dsMon
                 where m.TenMon.StartsWith("Lập trình")
                 select m.TenMon;
    var aMethod = dsMon.Where(m => m.TenMon.StartsWith("Lập trình")).Select(m => m.TenMon);
    Console.WriteLine("Query syntax :");
    foreach (var ten in aQuery) Console.WriteLine($"  {ten}");
    Console.WriteLine("Method syntax:");
    foreach (var ten in aMethod) Console.WriteLine($"  {ten}");

    //b. Môn hệ CD, số tiết giảm dần rồi mã môn tăng dần
    Cau("b. Các môn hệ CD, số tiết giảm dần, mã môn tăng dần");
    var bQuery = from m in dsMon
                 where m.He == "CD"
                 orderby m.SoTiet descending, m.MaMon
                 select m;
    var bMethod = dsMon.Where(m => m.He == "CD")
                       .OrderByDescending(m => m.SoTiet)
                       .ThenBy(m => m.MaMon);
    Console.WriteLine("Query syntax :");
    foreach (var m in bQuery) Console.WriteLine($"  {m}");
    Console.WriteLine($"Method syntax cho cùng kết quả: {bQuery.SequenceEqual(bMethod)}");

    //c. Môn có tên chứa "web" (không phân biệt hoa thường), chỉ lấy Tên môn và Hệ
    Cau("c. Các môn có tên chứa \"web\" (Tên môn, Hệ)");
    var cQuery = from m in dsMon
                 where m.TenMon.Contains("web", StringComparison.OrdinalIgnoreCase)
                 select new { m.TenMon, m.He };
    var cMethod = dsMon.Where(m => m.TenMon.Contains("web", StringComparison.OrdinalIgnoreCase))
                       .Select(m => new { m.TenMon, m.He });
    Console.WriteLine("Query syntax :");
    foreach (var x in cQuery) Console.WriteLine($"  {x.TenMon,-44} | {x.He}");
    Console.WriteLine("Method syntax:");
    foreach (var x in cMethod) Console.WriteLine($"  {x.TenMon,-44} | {x.He}");

    //d. Môn hệ KTV, sắp tăng theo mã môn
    Cau("d. Các môn hệ KTV, mã môn tăng dần");
    var dQuery = from m in dsMon
                 where m.He == "KTV"
                 orderby m.MaMon
                 select m;
    var dMethod = dsMon.Where(m => m.He == "KTV").OrderBy(m => m.MaMon);
    Console.WriteLine("Query syntax :");
    foreach (var m in dQuery) Console.WriteLine($"  {m}");
    Console.WriteLine($"Method syntax cho cùng kết quả: {dQuery.SequenceEqual(dMethod)}");
}

//Bài 5.2: thống kê trên List<MonHoc>
static void Bai52() {
    TieuDe("BÀI 5.2. THỐNG KÊ TRÊN List<MonHoc>");
    List<MonHoc> dsMon = DuLieu.DS_Mon();

    //a. Tổng số môn
    Cau("a. Tổng số môn hiện có");
    Console.WriteLine($"Tổng số môn: {dsMon.Count()}");

    //b. Số môn có tên bắt đầu bằng "Lập trình"
    Cau("b. Số môn có tên bắt đầu bằng \"Lập trình\"");
    Console.WriteLine($"Số môn: {dsMon.Count(m => m.TenMon.StartsWith("Lập trình"))}");

    //c. Tổng số tiết của hệ KTV
    Cau("c. Tổng số tiết của hệ Kỹ thuật viên (KTV)");
    int tongTietKTV = dsMon.Where(m => m.He == "KTV").Sum(m => (int)m.SoTiet);
    Console.WriteLine($"Tổng số tiết: {tongTietKTV}");

    //d. Tổng số môn của mỗi hệ
    Cau("d. Tổng số môn của mỗi hệ");
    var dTheoHe = from m in dsMon
                  group m by m.He into g
                  select new { He = g.Key, TongSoMon = g.Count() };
    Console.WriteLine($"{"Hệ",-8} | Tổng số môn");
    foreach (var x in dTheoHe) Console.WriteLine($"{TenHeHienThi(x.He),-8} | {x.TongSoMon}");

    //e. Nhóm theo số tiết, giảm dần theo số tiết
    Cau("e. Nhóm theo số tiết (giảm dần)");
    var eTheoTiet = dsMon.GroupBy(m => m.SoTiet)
                         .OrderByDescending(g => g.Key)
                         .Select(g => new { SoTiet = g.Key, TongSoMon = g.Count() });
    Console.WriteLine("Số tiết | Tổng số môn");
    foreach (var x in eTheoTiet) Console.WriteLine($"{x.SoTiet,7} | {x.TongSoMon}");

    //f. Môn có số tiết cao nhất (lấy tất cả nếu có nhiều môn bằng nhau)
    Cau("f. Môn học có số tiết cao nhất");
    byte tietMax = dsMon.Max(m => m.SoTiet);
    var fMax = dsMon.Where(m => m.SoTiet == tietMax);
    foreach (var m in fMax) Console.WriteLine(m);

    //g. Thống kê theo hệ: số môn, tổng tiết, tiết cao nhất, thấp nhất
    Cau("g. Thống kê theo Hệ");
    var gThongKe = from m in dsMon
                   group m by m.He into g
                   select new {
                       He = g.Key,
                       SoMon = g.Count(),
                       TongTiet = g.Sum(x => (int)x.SoTiet),
                       TietMax = g.Max(x => x.SoTiet),
                       TietMin = g.Min(x => x.SoTiet)
                   };
    Console.WriteLine($"{"Hệ",-8} | Số môn | Tổng tiết | Cao nhất | Thấp nhất");
    foreach (var x in gThongKe) {
        Console.WriteLine($"{TenHeHienThi(x.He),-8} | {x.SoMon,6} | {x.TongTiet,9} | {x.TietMax,8} | {x.TietMin,9}");
    }

    //h. Liệt kê các môn phân nhóm theo hệ
    Cau("h. Các môn học phân nhóm theo Hệ");
    var hNhom = dsMon.GroupBy(m => m.He);
    foreach (var g in hNhom) {
        Console.WriteLine($"Hệ {TenHeHienThi(g.Key)} ({g.Count()} môn):");
        foreach (var m in g) Console.WriteLine($"  {m}");
    }

    //i. Phân nhóm theo số tiết, tăng dần theo số tiết
    Cau("i. Các môn học phân nhóm theo Số tiết (tăng dần)");
    var iNhom = from m in dsMon
                group m by m.SoTiet into g
                orderby g.Key
                select g;
    foreach (var g in iNhom) {
        Console.WriteLine($"Số tiết {g.Key} ({g.Count()} môn):");
        foreach (var m in g) Console.WriteLine($"  {m}");
    }

    //j. Hệ KTV, phân nhóm theo học phần HP2..HP5, sắp theo mã môn
    Cau("j. Hệ KTV phân nhóm theo học phần");
    var jNhom = from m in dsMon
                where m.He == "KTV"
                orderby m.MaMon
                group m by m.MaMon.Substring(0, 3) into g
                orderby g.Key
                select g;
    foreach (var g in jNhom) {
        Console.WriteLine($"Học phần {g.Key}:");
        foreach (var m in g) Console.WriteLine($"  {m}");
    }

    //k. Phân nhóm theo hệ, chỉ lấy môn có số tiết > 40, mỗi nhóm sắp theo mã môn
    Cau("k. Phân nhóm theo Hệ, chỉ lấy môn có Số tiết > 40");
    var kNhom = dsMon.Where(m => m.SoTiet > 40)
                     .GroupBy(m => m.He)
                     .Select(g => new { He = g.Key, DsMon = g.OrderBy(m => m.MaMon) });
    foreach (var g in kNhom) {
        Console.WriteLine($"Hệ {TenHeHienThi(g.He)}:");
        foreach (var m in g.DsMon) Console.WriteLine($"  {m}");
    }
}

//Bài 6.1: in nguồn dữ liệu List<He> lấy từ DuLieu.DS_He()
static void Bai61() {
    TieuDe("BÀI 6.1. NGUỒN DỮ LIỆU List<He>");
    List<He> dsHe = DuLieu.DS_He();
    Console.WriteLine($"{"Mã hệ",-6} | Tên hệ");
    foreach (var h in dsHe) Console.WriteLine($"{h.MaHe,-6} | {h.TenHe}");
}

//Bài 6.2: join hai nguồn dữ liệu List<MonHoc> và List<He>
static void Bai62() {
    TieuDe("BÀI 6.2. JOIN VÀ CÁC TOÁN TỬ TẬP HỢP");
    List<MonHoc> dsMon = DuLieu.DS_Mon();
    List<He> dsHe = DuLieu.DS_He();

    //a. Inner join: Tên hệ, Mã môn, Tên môn
    Cau("a. Inner join: Tên hệ, Mã môn, Tên môn");
    var aQuery = from m in dsMon
                 join h in dsHe on m.He equals h.MaHe
                 select new { h.TenHe, m.MaMon, m.TenMon };
    var aMethod = dsMon.Join(dsHe, m => m.He, h => h.MaHe,
                             (m, h) => new { h.TenHe, m.MaMon, m.TenMon });
    foreach (var x in aQuery) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");
    Console.WriteLine($"Số dòng: {aQuery.Count()} (Method syntax: {aMethod.Count()})");

    //b. Left outer join: lấy cả hệ chưa có môn
    Cau("b. Left join: liệt kê cả hệ chưa có môn học");
    var heTraiMon = from h in dsHe
                    join m in dsMon on h.MaHe equals m.He into nhomMon
                    from m in nhomMon.DefaultIfEmpty()
                    select new {
                        TenHe = h.TenHe,
                        MaMon = m == null ? "" : m.MaMon,
                        TenMon = m == null ? "(chưa có môn học)" : m.TenMon
                    };
    foreach (var x in heTraiMon) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

    //Môn học không khớp với hệ nào (chưa khai báo hệ), dùng cho câu c và d
    var monChuaCoHe = from m in dsMon
                      join h in dsHe on m.He equals h.MaHe into nhomHe
                      from h in nhomHe.DefaultIfEmpty()
                      where h == null
                      select new {
                          TenHe = "(chưa khai báo hệ)",
                          MaMon = m.MaMon,
                          TenMon = m.TenMon
                      };

    //c. Full outer join = left join (hệ -> môn) + các môn chưa có hệ
    Cau("c. Liệt kê cả hệ chưa có môn và môn chưa khai báo hệ");
    var cFull = heTraiMon.Concat(monChuaCoHe);
    foreach (var x in cFull) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

    //d. Chỉ lấy phần không khớp của hai phía
    Cau("d. Chỉ hệ chưa có môn và môn chưa khai báo hệ");
    var heChuaCoMon = heTraiMon.Where(x => x.MaMon == "");
    var dKhongKhop = heChuaCoMon.Concat(monChuaCoHe);
    foreach (var x in dKhongKhop) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon}");

    //e. 5 môn đầu tiên có số tiết giảm dần
    Cau("e. 5 môn đầu tiên có số tiết giảm dần");
    var eTop5 = (from m in dsMon
                 join h in dsHe on m.He equals h.MaHe into nhomHe
                 from h in nhomHe.DefaultIfEmpty()
                 orderby m.SoTiet descending, m.MaMon
                 select new {
                     TenHe = h == null ? "(chưa khai báo hệ)" : h.TenHe,
                     m.MaMon,
                     m.TenMon,
                     m.SoTiet
                 }).Take(5);
    foreach (var x in eTop5) Console.WriteLine($"{x.TenHe,-18} | {x.MaMon,-6} | {x.TenMon,-44} | {x.SoTiet,3}");

    //f. Tổng số môn của mỗi hệ (GroupJoin giữ cả hệ có 0 môn)
    Cau("f. Tổng số môn học của mỗi hệ");
    var fTongMon = dsHe.GroupJoin(dsMon, h => h.MaHe, m => m.He,
                                  (h, nhomMon) => new { h.MaHe, h.TenHe, TongSoMon = nhomMon.Count() });
    Console.WriteLine($"{"Mã hệ",-6} | {"Tên hệ",-18} | Tổng số môn");
    foreach (var x in fTongMon) Console.WriteLine($"{x.MaHe,-6} | {x.TenHe,-18} | {x.TongSoMon}");

    //g. Số loại số tiết khác nhau
    Cau("g. Số loại Số tiết khác nhau");
    var gLoaiTiet = dsMon.Select(m => m.SoTiet).Distinct().OrderBy(t => t);
    Console.WriteLine($"Có {gLoaiTiet.Count()} loại số tiết: {string.Join(", ", gLoaiTiet)}");

    //h. Môn đầu tiên có tên bắt đầu bằng "Lập trình"
    Cau("h. Môn học đầu tiên có tên bắt đầu bằng \"Lập trình\"");
    MonHoc? hDauTien = dsMon.FirstOrDefault(m => m.TenMon.StartsWith("Lập trình"));
    Console.WriteLine(hDauTien == null ? "Không tìm thấy" : hDauTien.ToString());

    //i. Liệt kê môn theo từng hệ, đánh số thứ tự trong mỗi nhóm
    Cau("i. Các môn theo từng hệ, có số thứ tự trong nhóm");
    var iTheoHe = from m in dsMon
                  group m by m.He into g
                  join h in dsHe on g.Key equals h.MaHe into nhomHe
                  from h in nhomHe.DefaultIfEmpty()
                  select new {
                      TenHe = h == null ? "(chưa khai báo hệ)" : h.TenHe,
                      DsMon = g.OrderBy(m => m.MaMon)
                               .Select((m, i) => new { STT = i + 1, m.MaMon, m.TenMon })
                  };
    foreach (var g in iTheoHe) {
        Console.WriteLine($"{g.TenHe}:");
        foreach (var x in g.DsMon) Console.WriteLine($"  {x.STT,2}. {x.MaMon,-6} | {x.TenMon}");
    }
}

//Bài 4.1: lớp MonHoc mô tả một môn học
public class MonHoc {
    public string MaMon { get; set; } = "";
    public string TenMon { get; set; } = "";
    public string He { get; set; } = "";
    public byte SoTiet { get; set; }

    public override string ToString() =>
        $"{MaMon,-6} | {TenMon,-44} | {(He == "" ? "(trống)" : He),-7} | {SoTiet,3}";
}

//Bài 6.1: lớp He mô tả một hệ đào tạo
public class He {
    public string MaHe { get; set; } = "";
    public string TenHe { get; set; } = "";
}

//Lớp DuLieu cung cấp nguồn dữ liệu mẫu cho các bài 5 và 6
public static class DuLieu {
    //Bài 4.1: danh sách môn học
    public static List<MonHoc> DS_Mon() {
        return new List<MonHoc> {
            new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
            new MonHoc { MaMon = "JLCB", TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
            new MonHoc { MaMon = "LINQ", TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
            new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
            new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
            new MonHoc { MaMon = "CC++", TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
            new MonHoc { MaMon = "JQUE", TenMon = "JQuery", He = "CD", SoTiet = 22 },
            new MonHoc { MaMon = "XML", TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
            new MonHoc { MaMon = "CRYS", TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
            new MonHoc { MaMon = "BWEB", TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
            new MonHoc { MaMon = "XYZ", TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
        };
    }

    //Bài 6.1: danh sách hệ
    public static List<He> DS_He() {
        return new List<He> {
            new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
            new He { MaHe = "CD", TenHe = "Chuyên đề" },
            new He { MaHe = "QT", TenHe = "Chứng chỉ quốc tế" }
        };
    }
}
